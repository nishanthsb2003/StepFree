import serial, csv, time

PORT = "COM3"      # <-- change to your ESP32 port (ex: COM6, /dev/ttyUSB0)
BAUD = 115200

LABEL = "rest"     # <-- CHANGE THIS per recording: rest / walk / lift
DURATION_SEC = 30  # <-- how long to collect data
FILENAME = f"leg_emg_{LABEL}.csv"

print("Expected CSV columns: timestamp_ms, emg, label")
print("Example row: 1670000000000,0.012,rest")
print("Saving to:", FILENAME)

ser = serial.Serial(PORT, BAUD)
time.sleep(2)  # allow ESP32 to reset

with open(FILENAME, "w", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(["timestamp_ms", "emg", "label"])

    print("\nRecording", LABEL, "data...")
    start = time.time()

    while time.time() - start < DURATION_SEC:
        try:
            line = ser.readline().decode().strip()
            if line.isdigit():

                ts = int(time.time() * 1000)           # timestamp in ms
                emg_val = int(line)                    # raw EMG value

                writer.writerow([ts, emg_val, LABEL])
        except:
            pass

print("\nDONE! Saved:", FILENAME)
